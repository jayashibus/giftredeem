export default [
  {
    staff_pass_id: "STAFF_H123804820G",
    team_name: "BASS",
    created_at: "1623772799000",
  },
  {
    staff_pass_id: "MANAGER_T999888420B",
    team_name: "RUST",
    created_at: "1623772799000",
  },

  {
    staff_pass_id: "BOSS_T000000001P",
    team_name: "RUST",
    created_at: "1623872111000",
  },
];
